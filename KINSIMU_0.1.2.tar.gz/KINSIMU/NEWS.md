# KINSIMU 0.1.2

* Added a `NEWS.md` file to track changes to the package.
* A new argument "Th" has been added to EvaluatePanel() function, meaning the threshold identifying markers with frequency sum differ significantly from 1 (those with data errors).
* Fixed several bugs in IICAL(), trioPI() and LRgpgcam() functions;
* Added a pdf file containing the instruction of functions in this package as a vignette file;
* Updated the examples to make them more visible.