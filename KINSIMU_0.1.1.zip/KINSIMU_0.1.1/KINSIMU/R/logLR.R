#' @title Calculating CLR for a single case
#'
